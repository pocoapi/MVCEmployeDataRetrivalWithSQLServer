﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MVCEmployeData.Models
{
    public class EmployeContext : DbContext
    {
        public EmployeContext()
            :base("EmployeConnection")
        {

        }

        public DbSet<Employe> EmployeTable { get; set; }

    }
}