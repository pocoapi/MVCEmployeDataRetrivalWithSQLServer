﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace MVCEmployeData.Models
{
    [Table("EmployeDetails")]
    public class Employe
    {
        [Key]
        public string EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpTech { get; set; }
        public string EmpSalary { get; set; }
    }
}